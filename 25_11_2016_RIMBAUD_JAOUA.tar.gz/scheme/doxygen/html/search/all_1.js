var searchData=
[
  ['basic_2eh',['basic.h',['../basic_8h.html',1,'']]],
  ['basic_5fatome',['BASIC_ATOME',['../read_8c.html#a794da11e5e95baea1892357a25b44336a26a9892b61e0aa5a24c1c1c7d57ebaab',1,'read.c']]]
];
