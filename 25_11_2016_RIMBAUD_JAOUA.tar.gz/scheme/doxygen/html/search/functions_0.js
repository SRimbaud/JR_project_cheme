var searchData=
[
  ['check',['check',['../object_8h.html#aa8d164b8e7142d98aaff83ccfcd48409',1,'check(void *ptr, char *message):&#160;object.c'],['../object_8c.html#aa8d164b8e7142d98aaff83ccfcd48409',1,'check(void *ptr, char *message):&#160;object.c']]],
  ['check_5falloc',['check_alloc',['../object_8h.html#a457357b9ad319b66d3573aaeb2d77933',1,'check_alloc(void *ptr, char *message):&#160;object.c'],['../object_8c.html#a457357b9ad319b66d3573aaeb2d77933',1,'check_alloc(void *ptr, char *message):&#160;object.c']]],
  ['check_5ftype',['check_type',['../object_8h.html#aa57b70a35593ee0e9483282f796a5122',1,'check_type(object o, int sfs_type):&#160;object.c'],['../object_8c.html#aa57b70a35593ee0e9483282f796a5122',1,'check_type(object o, int sfs_type):&#160;object.c']]]
];
