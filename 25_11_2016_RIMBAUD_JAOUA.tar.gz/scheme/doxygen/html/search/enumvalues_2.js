var searchData=
[
  ['define',['DEFINE',['../object_8h.html#a0b6a835fc6107eae744ba88c03f404d4aff318ced96eeb59afb7dd091c7cf0903',1,'object.h']]]
];
