var searchData=
[
  ['env_5fdisable_5fcreation',['ENV_DISABLE_CREATION',['../object_8h.html#ad6ae71669c1596ca1e441c7da58c3655',1,'object.h']]],
  ['env_5fenable_5fcreation',['ENV_ENABLE_CREATION',['../object_8h.html#a4e8777591d506b4f54d8c4ff94cdf2a3',1,'object.h']]]
];
