var searchData=
[
  ['basic_5fatome',['BASIC_ATOME',['../read_8c.html#a794da11e5e95baea1892357a25b44336a26a9892b61e0aa5a24c1c1c7d57ebaab',1,'read.c']]]
];
