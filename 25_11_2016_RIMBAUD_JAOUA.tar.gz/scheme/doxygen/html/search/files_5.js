var searchData=
[
  ['primitive_2eh',['primitive.h',['../primitive_8h.html',1,'']]],
  ['print_2ec',['print.c',['../print_8c.html',1,'']]],
  ['print_2eh',['print.h',['../print_8h.html',1,'']]]
];
