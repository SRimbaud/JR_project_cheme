var searchData=
[
  ['quote',['QUOTE',['../object_8h.html#a0b6a835fc6107eae744ba88c03f404d4ada126905189f15af6d475cc45f0cb2b2',1,'object.h']]]
];
