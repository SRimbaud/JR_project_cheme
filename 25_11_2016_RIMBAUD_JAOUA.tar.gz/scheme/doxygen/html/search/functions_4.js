var searchData=
[
  ['make_5ffalse',['make_false',['../object_8h.html#a0c208c0fbec6ecf85e3de7949b7691cf',1,'make_false(void):&#160;object.c'],['../object_8c.html#a0c208c0fbec6ecf85e3de7949b7691cf',1,'make_false(void):&#160;object.c']]],
  ['make_5fforms',['make_forms',['../object_8h.html#aabab05a704acf24c0040b7223908c858',1,'make_forms():&#160;object.c'],['../object_8c.html#aabab05a704acf24c0040b7223908c858',1,'make_forms():&#160;object.c']]],
  ['make_5fnil',['make_nil',['../object_8h.html#a27cc84d64ba2ebc57634851dfa247bdd',1,'make_nil(void):&#160;object.c'],['../object_8c.html#a0175150d600f632a2675d80b72823f45',1,'make_nil(void):&#160;object.c']]],
  ['make_5fobject',['make_object',['../object_8h.html#a742a50e12ae185f989627ff4fcfe5440',1,'make_object(uint type):&#160;object.c'],['../object_8c.html#ae588b0336388f82cf984bca34a66fe99',1,'make_object(uint type):&#160;object.c']]],
  ['make_5ftrue',['make_true',['../object_8h.html#aa54a323be37760f91b9a423760d800d3',1,'make_true(void):&#160;object.c'],['../object_8c.html#aa54a323be37760f91b9a423760d800d3',1,'make_true(void):&#160;object.c']]]
];
