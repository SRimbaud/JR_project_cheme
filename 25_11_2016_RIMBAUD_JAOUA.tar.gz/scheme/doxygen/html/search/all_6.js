var searchData=
[
  ['if',['IF',['../object_8h.html#a0b6a835fc6107eae744ba88c03f404d4a252802eda493fb6b4a279c4452acb547',1,'object.h']]],
  ['if_5falternative',['IF_alternative',['../eval_8h.html#aefec57e38712b1baf88ee81276fe57ed',1,'IF_alternative(object input):&#160;eval.c'],['../eval_8c.html#aefec57e38712b1baf88ee81276fe57ed',1,'IF_alternative(object input):&#160;eval.c']]],
  ['if_5fconsequence',['IF_consequence',['../eval_8h.html#ae2d724e0225104a8dcd621f5f691c601',1,'IF_consequence(object input):&#160;eval.c'],['../eval_8c.html#ae2d724e0225104a8dcd621f5f691c601',1,'IF_consequence(object input):&#160;eval.c']]],
  ['if_5foverargument',['IF_overargument',['../eval_8h.html#a026bb47409acef4341f840fc817b292c',1,'IF_overargument(object input):&#160;eval.c'],['../eval_8c.html#a026bb47409acef4341f840fc817b292c',1,'IF_overargument(object input):&#160;eval.c']]],
  ['if_5fpredicat',['IF_predicat',['../eval_8h.html#a0059ac2d5fc1abec50561b5b9a1b494e',1,'IF_predicat(object input):&#160;eval.c'],['../eval_8c.html#a0059ac2d5fc1abec50561b5b9a1b494e',1,'IF_predicat(object input):&#160;eval.c']]],
  ['init_5finterpreter',['init_interpreter',['../repl_8c.html#ac7892fa748bffcd6854f8b7adeb40ba0',1,'repl.c']]],
  ['init_5fprimitive',['init_primitive',['../primitive_8h.html#a71008e3b64854232352e9a010b0ec70f',1,'primitive.c']]],
  ['is_5fform',['is_form',['../object_8h.html#a54510b61c6f3490e0d71cbc71cc4225a',1,'is_form(object symbol, FORMS *forme):&#160;object.c'],['../object_8c.html#a54510b61c6f3490e0d71cbc71cc4225a',1,'is_form(object symbol, FORMS *forme):&#160;object.c']]],
  ['isealnum',['isealnum',['../object_8h.html#a0fe65b3e6071e628e9dd27ceb779a253',1,'isealnum(char c):&#160;object.c'],['../object_8c.html#a0fe65b3e6071e628e9dd27ceb779a253',1,'isealnum(char c):&#160;object.c']]]
];
