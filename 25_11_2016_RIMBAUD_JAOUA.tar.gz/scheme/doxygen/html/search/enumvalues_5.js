var searchData=
[
  ['none',['NONE',['../object_8h.html#a0b6a835fc6107eae744ba88c03f404d4ac157bdf0b85a40d2619cbc8bc1ae5fe2',1,'object.h']]],
  ['nothing',['NOTHING',['../read_8c.html#a794da11e5e95baea1892357a25b44336acfe24a7b308a82835c8a9a9a89bc4ca2',1,'read.c']]]
];
