var searchData=
[
  ['wait_5ffirst_5fnon_5fblank_5fchar',['wait_first_non_blank_char',['../object_8h.html#a8db21bf1c03bc99e813b38a77ff8792e',1,'wait_first_non_blank_char(char *s1, uint *s1_cursor):&#160;object.c'],['../object_8c.html#a8db21bf1c03bc99e813b38a77ff8792e',1,'wait_first_non_blank_char(char *s1, uint *s1_cursor):&#160;object.c']]]
];
