var searchData=
[
  ['first_5fusefull_5fchar',['first_usefull_char',['../read_8c.html#a5f436bcd6cba7ebae92b4278d43cf7d9',1,'read.c']]],
  ['flip',['flip',['../read_8c.html#a2944755a32d2f89b5585df862eaa4980',1,'read.c']]]
];
