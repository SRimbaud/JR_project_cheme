var searchData=
[
  ['env',['env',['../object_8h.html#a062b7366fcc9f920dbb8475d815e0bfc',1,'env():&#160;repl.c'],['../repl_8c.html#a062b7366fcc9f920dbb8475d815e0bfc',1,'env():&#160;repl.c']]],
  ['env_5fadd_5fvar',['ENV_add_var',['../object_8h.html#aad94ca4613c4d0f6214c77363f55008f',1,'ENV_add_var(object name, object value):&#160;object.c'],['../object_8c.html#aad94ca4613c4d0f6214c77363f55008f',1,'ENV_add_var(object name, object value):&#160;object.c']]],
  ['env_5fbuild',['ENV_build',['../object_8h.html#a13394f7830becff1f3558b6f5b0969f9',1,'ENV_build(object father):&#160;object.c'],['../object_8c.html#a13394f7830becff1f3558b6f5b0969f9',1,'ENV_build(object father):&#160;object.c']]],
  ['env_5fcheck_5floop',['ENV_check_loop',['../object_8h.html#a7fb587a2ac0a4bebac5317ece2968594',1,'ENV_check_loop(object name):&#160;object.c'],['../object_8c.html#a7fb587a2ac0a4bebac5317ece2968594',1,'ENV_check_loop(object name):&#160;object.c']]],
  ['env_5fdisable_5fcreation',['ENV_DISABLE_CREATION',['../object_8h.html#ad6ae71669c1596ca1e441c7da58c3655',1,'object.h']]],
  ['env_5fenable_5fcreation',['ENV_ENABLE_CREATION',['../object_8h.html#a4e8777591d506b4f54d8c4ff94cdf2a3',1,'object.h']]],
  ['env_5fget_5fvar',['ENV_get_var',['../object_8h.html#a9408de05ed658e0c2b39b06dfa52afc9',1,'ENV_get_var(object var, int *flag):&#160;object.c'],['../object_8c.html#a9408de05ed658e0c2b39b06dfa52afc9',1,'ENV_get_var(object var, int *flag):&#160;object.c']]],
  ['env_5fget_5fvar_5fin_5fenv',['ENV_get_var_in_env',['../object_8h.html#a6c450315c9bb5fc8d72fe422bccad428',1,'ENV_get_var_in_env(object var, object environ, int *flag):&#160;object.c'],['../object_8c.html#a6c450315c9bb5fc8d72fe422bccad428',1,'ENV_get_var_in_env(object var, object environ, int *flag):&#160;object.c']]],
  ['env_5fupdate_5fvar',['ENV_update_var',['../object_8h.html#a700e3a4614699deb08c3640cd18af8e3',1,'ENV_update_var(object name, const object val, int mode, int *free_flag):&#160;object.c'],['../object_8c.html#a700e3a4614699deb08c3640cd18af8e3',1,'ENV_update_var(object name, const object val, int mode, int *free_flag):&#160;object.c']]],
  ['eval_2ec',['eval.c',['../eval_8c.html',1,'']]],
  ['eval_2eh',['eval.h',['../eval_8h.html',1,'']]],
  ['eval_5fand',['EVAL_and',['../eval_8h.html#a5d2f9663d35a3771d2199c8a982571db',1,'EVAL_and(object o):&#160;eval.c'],['../eval_8c.html#a5d2f9663d35a3771d2199c8a982571db',1,'EVAL_and(object o):&#160;eval.c']]],
  ['eval_5fdefine',['EVAL_define',['../eval_8h.html#a3ab5f3daaa76ecdb200516edaeb5f1de',1,'EVAL_define(object o):&#160;eval.c'],['../eval_8c.html#a3ab5f3daaa76ecdb200516edaeb5f1de',1,'EVAL_define(object o):&#160;eval.c']]],
  ['eval_5fif',['EVAL_if',['../eval_8h.html#a92d6d091093aca2cc461305af9898a57',1,'EVAL_if(object o):&#160;eval.c'],['../eval_8c.html#a92d6d091093aca2cc461305af9898a57',1,'EVAL_if(object o):&#160;eval.c']]],
  ['eval_5for',['EVAL_or',['../eval_8h.html#a8cf3f371a46ed2d9a0c49c65397b704f',1,'EVAL_or(object o):&#160;eval.c'],['../eval_8c.html#a8cf3f371a46ed2d9a0c49c65397b704f',1,'EVAL_or(object o):&#160;eval.c']]],
  ['eval_5fquote',['EVAL_quote',['../eval_8h.html#ab3046168bcbd3ea1c3b2b256c52f3381',1,'EVAL_quote(object o):&#160;eval.c'],['../eval_8c.html#ab3046168bcbd3ea1c3b2b256c52f3381',1,'EVAL_quote(object o):&#160;eval.c']]],
  ['eval_5fset',['EVAL_set',['../eval_8h.html#aaf33772424539f09fb5cf02f68539a27',1,'EVAL_set(object o):&#160;eval.c'],['../eval_8c.html#aaf33772424539f09fb5cf02f68539a27',1,'EVAL_set(object o):&#160;eval.c']]],
  ['expression_5ftype_5ft',['EXPRESSION_TYPE_T',['../read_8c.html#a794da11e5e95baea1892357a25b44336',1,'read.c']]]
];
